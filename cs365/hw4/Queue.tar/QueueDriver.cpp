#include "Queue.h"
#include <cstdio>

using namespace std;

/* Nicholas Creech
 * CS365 HW4
 * 02/22/21
 */ 

int main()
{
	Queue *testQueue = new ArrayQueue;

	testQueue->add(3);
	testQueue->add(10);
	testQueue->add(5);
	
	printf("%d\n", testQueue->remove());
	printf("%d\n", testQueue->remove());

	testQueue->add(6);
	testQueue->add(9);
	testQueue->add(12);

	while(!testQueue->isEmpty())
		printf("%d\n", testQueue->remove());

	delete testQueue;
	return 0;
}
