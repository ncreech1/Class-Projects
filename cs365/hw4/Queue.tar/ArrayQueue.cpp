#include "Queue.h"
#include <cstdlib>
#include <iostream>

using namespace std;

/* Nicholas Creech
 * CS365 HW4
 * 02/22/21
 */

void ArrayQueue::add(int value)
{
	innerList.push_back(value);
}

int ArrayQueue::remove()
{
	if(!innerList.empty())
	{
		int val = innerList.front();
		innerList.pop_front();
		return val;
	}

	cout << "ArrayQueue: Cannot call remove on empty queue!\n";
	exit(1);
}

bool ArrayQueue::isEmpty()
{
	return innerList.empty();
}
