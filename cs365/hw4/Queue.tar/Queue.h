#include <list>

/* Nicholas Creech
 * CS365 HW4
 * 02/22/21
 */ 

class Queue
{
	public:
		virtual void add(int value) = 0;
		virtual int remove() = 0;
		virtual bool isEmpty() = 0;
};

class ArrayQueue : public Queue
{
	public:
		void add(int value);
		int remove();
		bool isEmpty();
	private:
		std::list<int> innerList;
};
